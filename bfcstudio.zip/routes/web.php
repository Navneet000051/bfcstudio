<?php

use App\Http\Controllers\PageController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PageController::class, 'home'])->name('home');
Route::get('/book-studio', [PageController::class, 'bookStudio'])->name('book-studio');
Route::get('/faq', [PageController::class, 'faq'])->name('faq');
