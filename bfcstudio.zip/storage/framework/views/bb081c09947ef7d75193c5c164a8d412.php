<div class="col-lg-4 col-md-6">
    <div class="bfc-price-card <?php if($pkg['featured']): ?> featured <?php endif; ?>">
        <div class="bfc-price-name"><?php echo e($pkg['name']); ?></div>
        <div class="bfc-price-amount">₹<?php echo e($pkg['price']); ?><small>/hour</small></div>
        <div class="bfc-price-gst">(Inclusive of GST)</div>
        <ul class="bfc-price-features">
            <?php $__currentLoopData = $pkg['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><i class="bi bi-check-circle-fill"></i> <?php echo e($feature); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <a href="<?php echo e(route('book-studio')); ?>" class="btn <?php if($pkg['featured']): ?> bfc-btn-primary <?php else: ?> bfc-btn-outline <?php endif; ?> bfc-btn-block">
            <i class="bi bi-check-circle"></i> Select Plan
        </a>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\bfcstudio\resources\views/partials/price-card.blade.php ENDPATH**/ ?>